@extends('layouts.app')

@section('title','Pesanans')

@section('content')
<form action="/pesanans/{{$pesanan['id']}}" method="POST">
@csrf
@method('PUT')
  <div class="form-group">
    <label for="exampleInputEmail1">Nama Pemesan</label>
    <input type="text" class="form-control" id="exampleInputEmail1" name="nama_pemesan" aria-describedby="emailHelp"  
    value="{{old('nama_pemesan')? old('nama_pemesan'):$pesanan['nama_pemesan']}}">
    @error('nama_pemesan')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Alamat Pemesan</label>
    <input type="text" class="form-control"name="alamat_pemesan" id="exampleInputPassword1"
    value="{{old('alamat_pemesan')? old('alamat_pemesan'):$pesanan['alamat_pemesan']}}">
    @error('alamat_pemesan')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">No Telepon</label>
    <input type="text" class="form-control" name="notelpon_pemesan" id="exampleInputPassword1"
    value="{{old('notelpon_pemesan')? old('notelpon_pemesan'):$pesanan['notelpon_pemesan']}}">
    @error('notelpon_pemesan')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">No Telepon</label>
    <input type="text" class="form-control" name="jumlah_dipesan" id="exampleInputPassword1"
    value="{{old('jumlah_dipesan')? old('jumlah_dipesan'):$pesanan['jumlah_dipesan']}}">
    @error('jumlah_dipesan')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Ukuran</label>
    <input type="text" class="form-control" name="ukuran" id="exampleInputPassword1" value="{{old('ukuran')}}">
    @error('ukuran')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Barang Yang Dipesan</label>
    <input type="text" class="form-control" name="barang_dipesan" id="exampleInputPassword1"
    value="{{old('barang_dipesan')? old('barang_dipesan'):$pesanan['barang_dipesan']}}">
    @error('barang_dipesan')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  <button type="submit" class="btn btn-primary">Edit Pesanan</button>
</form> 

@endsection
  

