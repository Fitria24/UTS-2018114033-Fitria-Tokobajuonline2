@extends('layouts.app')

@section('title','Pesanans')

@section('content')
<form action="/pesanans" method="POST">
@csrf
  <div class="form-group">
    <label for="exampleInputEmail1">Nama Pemesan</label>
    <input type="text" class="form-control" id="exampleInputEmail1" name="nama_pemesan" aria-describedby="emailHelp" value="{{old('nama_pemesan')}}">
    @error('nama_pemesan')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Alamat Pemesan</label>
    <input type="text" class="form-control"name="alamat_pemesan" id="exampleInputPassword1" value="{{old('alamat_pemesan')}}">
    @error('alamat_pemesan')
    <div class="alert alert-danger">{{ $message }}</div>
     @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">No Telepon</label>
    <input type="text" class="form-control" name="notelpon_pemesan" id="exampleInputPassword1" value="{{old('notelpon_pemesan')}}">
    @error('notelpon_pemesan')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Jumlah Di Pesan</label>
    <input type="text" class="form-control" name="jumlah_dipesan" id="exampleInputPassword1" value="{{old('jumlah_dipesan')}}">
    @error('jumlah_dipesan')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Ukuran</label>
    <input type="text" class="form-control" name="ukuran"id="exampleInputPassword1" value="{{old('ukuran')}}">
    @error('ukuran')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Barang Yang Di Pesan</label>
    <input type="text" class="form-control" name="barang_dipesan" id="exampleInputPassword1" value="{{old('barang_dipesan')}}">
    @error('barang_dipesan')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  
  <button type="submit" class="btn btn-primary">Pesan</button>
</form> 

@endsection
  

