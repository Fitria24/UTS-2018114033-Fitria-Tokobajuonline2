@extends('layouts.app')

@section('title','Toko Baju Online')

@section('content')
<div class="card">
    <div class="card-body">
    <h3> Nama Pemesan: {{$pesanan['nama_pemesan']}}</h3>
    <h3> Alamat Pemesan : {{$pesanan['alamat_pemesan']}}</h3>
    <h3> No Telepon  {{$pesanan['notelpon_pemesan']}}</h3>
    <h3> Jumlah Yang Dipesan  {{$pesanan['jumlah_dipesan']}}</h3>
    <h3> Ukuran : {{$pesanan['ukuran']}}</h3>
    <h3> Barang Yang Di Pesan : {{$pesanan['barang_dipesan']}}</h3>
    </div>
</div>
@endsection
  