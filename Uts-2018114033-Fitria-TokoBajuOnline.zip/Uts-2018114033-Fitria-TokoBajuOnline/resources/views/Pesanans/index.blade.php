@extends('layouts.app')

@section('title','Pesanans')

@section('content')
<a href="/pesanans/create" class="card-link btn-primary">Buat Pesanan</a>
@foreach ($pesanans as $pesanan)
<div class="card" style="width: 26rem;">
  <div class="card-body">
    <a href="/barangs/{{$pesanan['id']}}"class="card-title">Nama Pemesan: {{ $pesanan['nama_pemesan'] }}</a>
    <p class="card-subtitle mb-2 text-muted">Alamat Pemesan:{{ $pesanan['alamat_pemesan'] }}</p>
    <p class="card-text">No Telepon:{{ $pesanan['notelpon_pemesan'] }}</p>
    <p class="card-text">Jumlah Yang Di Pesan:{{ $pesanan['jumlah_dipesan'] }}</p>
    <p class="card-text">Ukuran:{{ $pesanan['ukuran'] }}</p>
    <p class="card-text">Barang Yang Di Pesan:{{ $pesanan['barang_dipesan'] }}</p>

    <a href="/pesanans/{{$pesanan['id']}}/edit" button class="card-link btn-warning">Edit Pesanan</a>
    <form action="/pesanans/{{$pesanan['id']}}" method="POST">
    @csrf
    @method('DELETE')
    <button class="card-link btn-danger">Hapus Pesanan</button>
    </form>
  </div>
</div>
   
@endforeach
{{$pesanans->links()}}
@endsection
  

