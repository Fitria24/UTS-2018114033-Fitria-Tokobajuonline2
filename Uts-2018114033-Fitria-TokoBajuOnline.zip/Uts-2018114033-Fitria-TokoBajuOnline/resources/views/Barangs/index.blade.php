@extends('layouts.app')

@section('title','Barangs')

@section('content')
<a href="/barangs/create" class="card-link btn-primary">Tambah Barang</a>
@foreach ($barangs as $barang)
<div class="card" style="width: 26rem;">
  <div class="card-body">
    <a href="/barangs/{{$barang['id']}}"class="card-title">Kode Barang: {{ $barang['kode_barang'] }}</a>
    <p class="card-subtitle mb-2 text-muted">Nama Barang:{{ $barang['nama_barang'] }}</p>
    <p class="card-text">Harga Barang:{{ $barang['harga_barang'] }}</p>
    <p class="card-text">Jumlah Barang:{{ $barang['jumlah_barang'] }}</p>
    <p class="card-text"> Ukuran: {{ $barang['keterangan'] }}</p>

    <a href="/barangs/{{$barang['id']}}/edit" button class="card-link btn-warning">Edit Barang</a>
    <form action="/barangs/{{$barang['id']}}" method="POST">
    @csrf
    @method('DELETE')
    <button class="card-link btn-danger">Hapus Barang</button>
    </form>
  </div>
</div>
   
@endforeach
{{$barangs->links()}}
@endsection
  

