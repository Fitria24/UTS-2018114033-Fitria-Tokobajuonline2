@extends('layouts.app')

@section('title','Toko Baju Online')

@section('content')
<div class="card">
    <div class="card-body">
    <h3> Kode Barang: {{$barang['kode_barang']}}</h3>
    <h3> Nama Barang : {{$barang['nama_barang']}}</h3>
    <h3> Harga Barang : {{$barang['harga_barang']}}</h3>
    <h3> Jumlah Barang: {{$barang['jumlah_barang']}}</h3>
    <h3> Ukuran : {{$barang['keterangan']}}</h3>
    </div>
</div>
@endsection
  