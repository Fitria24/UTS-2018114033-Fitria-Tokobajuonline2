@extends('layouts.app')

@section('title','Barangs')

@section('content')
<form action="/barangs/{{$barang['id']}}" method="POST">
@csrf
@method('PUT')
  <div class="form-group">
    <label for="exampleInputEmail1">Kode Barang</label>
    <input type="text" class="form-control" id="exampleInputEmail1" name="kode_barang" aria-describedby="emailHelp"  
    value="{{old('kode_barang')? old('kode_barang'):$barang['kode_barang']}}">
    @error('kode_barang')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Nama Barang</label>
    <input type="text" class="form-control"name="nama_barang" id="exampleInputPassword1"
    value="{{old('nama_barang')? old('nama_barang'):$barang['nama_barang']}}">
    @error('nama_barang')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Harga Barang</label>
    <input type="text" class="form-control" name="harga_barang" id="exampleInputPassword1"
    value="{{old('harga_barang')? old('harga_barang'):$barang['harga_barang']}}">
    @error('harga_barang')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Jumlah Barang</label>
    <input type="text" class="form-control" name="jumlah_barang" id="exampleInputPassword1"
    value="{{old('jumlah_barang')? old('jumlah_barang'):$barang['jumlah_barang']}}">
    @error('jumlah_barang')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Ukuran</label>
    <input type="text" class="form-control" name="keterangan" id="exampleInputPassword1"
    value="{{old('keterangan')? old('keterangan'):$barang['keterangan']}}">
    @error('keterangan')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  <button type="submit" class="btn btn-primary">Edit Barang</button>
</form> 

@endsection
  

