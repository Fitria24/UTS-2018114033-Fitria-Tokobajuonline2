@extends('layouts.app')

@section('title','Barangs')

@section('content')
<form action="/barangs" method="POST">
@csrf
  <div class="form-group">
    <label for="exampleInputEmail1">Kode Barang</label>
    <input type="text" class="form-control" id="exampleInputEmail1" name="kode_barang" aria-describedby="emailHelp" value="{{old('kode_barang')}}">
    @error('kode_barang')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Nama Barang</label>
    <input type="text" class="form-control"name="nama_barang" id="exampleInputPassword1" value="{{old('nama_barang')}}">
    @error('nama_barang')
    <div class="alert alert-danger">{{ $message }}</div>
     @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Harga Barang</label>
    <input type="text" class="form-control" name="harga_barang" id="exampleInputPassword1" value="{{old('harga_barang')}}">
    @error('harga_barang')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Jumlah Barang</label>
    <input type="text" class="form-control" name="jumlah_barang" id="exampleInputPassword1" value="{{old('jumlah_barang')}}">
    @error('jumlah_barang')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Ukuran</label>
    <input type="text" class="form-control" name="keterangan" id="exampleInputPassword1" value="{{old('keterangan')}}">
    @error('keterangan')
    <div class="alert alert-danger">{{ $message }}</div>
    @enderror
  </div>
  
  <button type="submit" class="btn btn-primary">Tambah Barang</button>
</form> 

@endsection
  

